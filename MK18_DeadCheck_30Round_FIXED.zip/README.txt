# MK18 — Dead Check custom weapon

- Magazine: 30
- Native base: SAR-15
- Visual target: AR-15/MK18 gun-only renderer set
- RPM: 800
- Reload: 2.5 seconds
- Uses weapon-space mounting.

Import this folder as a data-only Custom Weapons package through F8.
