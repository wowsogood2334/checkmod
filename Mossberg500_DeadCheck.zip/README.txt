Mossberg 500 - Dead Check Custom Weapon

Base: R-870
Capacity: 8 shells

Install through F8 > Custom Weapons.
DLL 1.1.0+ required for weaponSpace/replaceRenderers.
